import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.base import BaseEstimator, RegressorMixin
import scipy.stats as stats

# Load the Boston Housing dataset
boston = load_boston()
X, y = boston.data, boston.target

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Normalize the features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Define the PyTorch regression model
class SimpleLinearRegression(nn.Module):
    def __init__(self, input_dim):
        super(SimpleLinearRegression, self).__init__()
        self.linear = nn.Linear(input_dim, 1)
    
    def forward(self, x):
        return self.linear(x)

# Define a function to train the model
def train_model(model, X_train, y_train, learning_rate, num_epochs):
    criterion = nn.MSELoss()
    optimizer = optim.SGD(model.parameters(), lr=learning_rate)
    
    X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
    y_train_tensor = torch.tensor(y_train, dtype=torch.float32).view(-1, 1)
    
    model.train()
    for epoch in range(num_epochs):
        optimizer.zero_grad()
        outputs = model(X_train_tensor)
        loss = criterion(outputs, y_train_tensor)
        loss.backward()
        optimizer.step()
    
    return model

# Define a custom regressor for use with RandomizedSearchCV
class PyTorchRegressor(BaseEstimator, RegressorMixin):
    def __init__(self, learning_rate=0.01, num_epochs=100, input_dim=13):
        self.learning_rate = learning_rate
        self.num_epochs = num_epochs
        self.input_dim = input_dim
        self.model = SimpleLinearRegression(input_dim)
    
    def fit(self, X, y):
        self.model = train_model(self.model, X, y, self.learning_rate, self.num_epochs)
    
    def predict(self, X):
        self.model.eval()
        X_tensor = torch.tensor(X, dtype=torch.float32)
        with torch.no_grad():
            predictions = self.model(X_tensor).numpy()
        return predictions.flatten()

# Define the hyperparameter distribution
param_dist = {
    'learning_rate': stats.uniform(0.001, 0.1),
    'num_epochs': stats.randint(50, 300),
}

# Perform random search
random_search = RandomizedSearchCV(
    estimator=PyTorchRegressor(input_dim=X_train.shape[1]),
    param_distributions=param_dist,
    n_iter=10,
    cv=3,
    scoring='neg_mean_squared_error',
    random_state=42
)
random_search.fit(X_train_scaled, y_train)

# Get the best hyperparameters
best_params = random_search.best_params_
print("Best hyperparameters:", best_params)

# Train the best model on the full training set
best_model = PyTorchRegressor(
    input_dim=X_train.shape[1],
    learning_rate=best_params['learning_rate'],
    num_epochs=best_params['num_epochs']
)
best_model.fit(X_train_scaled, y_train)

# Make predictions on the test set
y_pred = best_model.predict(X_test_scaled)

# Calculate regression metrics
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)

print(f"MAE: {mae}")
print(f"MSE: {mse}")
print(f"RMSE: {rmse}")
print(f"R-squared: {r2}")
